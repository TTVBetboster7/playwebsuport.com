function togglemenu(){
  if(menuList.style.maxHeight) == 0
  {
    menuList.style.maxHeight = "130px" 
  }
  else
  {
    menuList.style.maxHeight = "0px"
  }